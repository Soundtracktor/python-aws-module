from setuptools import setup

setup(
    name='aws',
    version='1.0.0',
    packages=['aws'],
    install_requires=['boto3'],
)
